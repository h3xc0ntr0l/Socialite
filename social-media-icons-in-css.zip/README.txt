A Pen created at CodePen.io. You can find this one at http://codepen.io/h3xc0ntr0l/pen/GpmyGQ.

 pluggable, mobile friendly css social media icons