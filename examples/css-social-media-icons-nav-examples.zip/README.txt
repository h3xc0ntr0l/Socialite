A Pen created at CodePen.io. You can find this one at http://codepen.io/h3xc0ntr0l/pen/MamOwE.

 Static styled arrow that is intended to have pretty transitions and use the social media icons located http://codepen.io/h3xc0ntr0l/pen/epWJVY